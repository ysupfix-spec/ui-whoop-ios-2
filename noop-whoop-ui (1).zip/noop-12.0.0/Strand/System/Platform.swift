import SwiftUI

#if canImport(AppKit)
import AppKit
/// The native bitmap image type for the current platform.
public typealias PlatformImage = NSImage
#elseif canImport(UIKit)
import UIKit
public typealias PlatformImage = UIImage
#endif

// MARK: - Image bridging

extension Image {
    /// Build a SwiftUI `Image` from the platform-native bitmap type (`NSImage` on macOS,
    /// `UIImage` on iOS) so call sites stay platform-agnostic.
    init(platformImage: PlatformImage) {
        #if canImport(AppKit)
        self.init(nsImage: platformImage)
        #elseif canImport(UIKit)
        self.init(uiImage: platformImage)
        #endif
    }
}

// MARK: - Pasteboard

/// Cross-platform clipboard write. `NSPasteboard` on macOS, `UIPasteboard` on iOS.
enum PlatformPasteboard {
    static func copy(_ string: String) {
        #if canImport(AppKit)
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(string, forType: .string)
        #elseif canImport(UIKit)
        UIPasteboard.general.string = string
        #endif
    }
}

// MARK: - Device noun (#225)

/// The platform's device noun, so user-facing copy reads correctly per platform instead of
/// hard-coding "Mac" everywhere (which is wrong on iPhone). Use these in any string that talks
/// about *this* device generically — NOT in strings about a Mac that are genuinely Mac-only
/// (e.g. "a Mac can't write to a 5/MG", or the Lock-the-Mac automation).
enum Platform {
    /// "iPhone" on iOS, "Mac" on macOS. e.g. "Everything stays on your \(Platform.deviceNoun)."
    static var deviceNoun: String {
        #if os(iOS)
        return "iPhone"
        #else
        return "Mac"
        #endif
    }

    /// "this iPhone" / "this Mac", the common demonstrative form. Localized so the demonstrative
    /// reads natively when interpolated into translated copy (key "this %@"); the noun itself is a
    /// product name and stays as-is.
    static var deviceNounPhrase: String { String(localized: "this \(deviceNoun)") }
}

// MARK: - Opening URLs

/// Cross-platform "open this URL with the system" helper. Used for `mailto:` and `shortcuts://`.
enum PlatformOpen {
    @MainActor static func url(_ url: URL) {
        #if canImport(AppKit)
        NSWorkspace.shared.open(url)
        #elseif canImport(UIKit)
        UIApplication.shared.open(url)
        #endif
    }
}

// MARK: - Screen idle (keep-awake for hands-free sessions)

/// Prevent the display from auto-locking during a live, watched session (the breathing
/// orb, the HIIT interval timer). iOS-only; a no-op on macOS, which has no idle-lock
/// concern for these screens. Apple guidance: set `true` only while genuinely needed and
/// reset to `false` the moment the session ends so the system idle timer resumes normally.
///
/// `isIdleTimerDisabled` is one process-wide flag, so independent holders are tracked by reason: a strap
/// sync finishing must not let the screen lock under a breathing session that is still running.
enum ScreenIdle {
    enum Reason: Hashable {
        /// A watched on-screen session (breathing, intervals, workout, HRV snapshot) via `keepAwake`.
        case session
        /// A strap history sync, while Settings → "Keep screen on while syncing" is on (iOS).
        case strapSync
    }

    /// UserDefaults key for the "Keep screen on while syncing" toggle (default OFF). iOS-only behaviour;
    /// declared here so the shared SettingsView and the iOS observer read one spelling.
    static let strapSyncKeepAwakeKey = "syncKeepScreenOn"

    @MainActor private static var holds: Set<Reason> = []

    /// True while any reason holds the screen awake. Read by tests; the platform flag mirrors it.
    @MainActor static var isHeld: Bool { !holds.isEmpty }

    /// Existing single-session API: last writer wins among sessions, exactly as before reasons existed.
    @MainActor static func keepAwake(_ on: Bool) {
        hold(.session, on)
    }

    @MainActor static func hold(_ reason: Reason, _ on: Bool) {
        if on { holds.insert(reason) } else { holds.remove(reason) }
        #if os(iOS)
        UIApplication.shared.isIdleTimerDisabled = !holds.isEmpty
        #endif
    }
}
